package com.amazon.buspassmanagement;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.buspassmanagement.controller.AuthenticationService;
import com.amazon.buspassmanagement.db.BusPassDAO;
import com.amazon.buspassmanagement.db.FeedbackDAO;
import com.amazon.buspassmanagement.db.StopDAO;
import com.amazon.buspassmanagement.db.VehicleDAO;
import com.amazon.buspassmanagement.model.BusPass;
import com.amazon.buspassmanagement.model.Feedback;
import com.amazon.buspassmanagement.model.Stop;
import com.amazon.buspassmanagement.model.User;
import com.amazon.buspassmanagement.model.Vehicle;

// Reference Link to Use JUnit as Testing Tool in your Project
// https://maven.apache.org/surefire/maven-surefire-plugin/examples/junit.html

public class AppTest {
    
	AuthenticationService authService = AuthenticationService.getInstance();
	
	// UNIT TESTS
	
	@Test
	public void testUserLogin() {
		
		User user = new User();
		user.email = "sia@example.com";
		//user.password = "sia123";
		user.password = "IoZ/qxiCszvPygUg2hfAQTFAELOEwMxKzireBmUFk5w=";
		
		boolean result = authService.loginUser(user);
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		
	}
	
	@Test
	public void testAdminLogin() {
		
		User user = new User();
		user.email = "john@example.com";
		user.password = "admin123";
		
		boolean result = authService.loginUser(user);
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		Assert.assertEquals(1, user.type); // 1 should be equal to 1
		
	}
	
	@Test
	public void testPassValidity() {
		
		BusPass pass = new BusPass();
		BusPassDAO passdao = new BusPassDAO();
		pass.id = 1;
		
		boolean result = false;
		
		String sql = "Select * from BusPass where id = '"+pass.id+"'";
		List<BusPass> buspass = passdao.retrieve(sql);
		
		LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = currentDate.format(formatter);
        
        int val = formattedDate.compareTo(buspass.get(0).validTill);
        if(val<0) {
        	result = true;
        }

		Assert.assertEquals(true, result);
			
	}
	
	@Test
	public void vehicleExists() {
		
		boolean result = false;
		VehicleDAO vehicledao = new VehicleDAO();
		
		String sql = "Select * from Vehicle where routeID = 2";
		List<Vehicle> vehicles = vehicledao.retrieve(sql);
		
		if(!vehicles.isEmpty()) {
			result = true;
		}
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void stopExists() {
		
		boolean result = false;
		StopDAO stopdao = new StopDAO();
		
		String sql = "Select * from Stop where routeID = 2";
		List<Stop> stops = stopdao.retrieve(sql);
		
		if(!stops.isEmpty()) {
			result = true;
		}
		
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void twoStopsExist() {
		
		boolean result = false;
		StopDAO stopdao = new StopDAO();
		
		String sql = "Select * from Stop where routeID = 2";
		List<Stop> stops = stopdao.retrieve(sql);
		
		if(stops.size()>=2) {
			result = true;
		}
		
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void raiseComplaint() {
		
		boolean result = false;
		Feedback feedback = new Feedback();
		FeedbackDAO feedbackdao = new FeedbackDAO();
		
		feedback.description = "The bus on my route is very dirty";
		feedback.type = 2;
		feedback.userId = 11;
		feedback.raisedBy = "annu@example.com";
		
		

		int val = feedbackdao.insert(feedback);
		if(val>0) {
			result = true;
		}
		
		Assert.assertEquals(true, result);
		
	}
	
}
