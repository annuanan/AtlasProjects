package com.amazon.busPassManagement;

import com.amazon.busPassManagement.model.User;

public class BusPassSession {
	
	public static User user = null;

}


