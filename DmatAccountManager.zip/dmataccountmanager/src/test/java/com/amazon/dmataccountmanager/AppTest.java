package com.amazon.dmataccountmanager;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.dmataccountmanager.controller.UserManagement;
import com.amazon.dmataccountmanager.db.UserDAO;
import com.amazon.dmataccountmanager.model.Users;



// Reference Link to Use JUnit as Testing Tool in your Project
// https://maven.apache.org/surefire/maven-surefire-plugin/examples/junit.html

public class AppTest {
    
	UserManagement manageuser = UserManagement.getInstance();
	
	// UNIT TESTS
	
	@Test
	public void testUserLogin() {
		
		Users user = new Users();
		user.accountNumber = "1001";
		user.password = "pooja123";
		
		boolean result = manageuser.login(user);
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		
	}
	
	@Test
	public void testUserRegisteration() {
		
		Users user = new Users();
		UserDAO userdao = new UserDAO();
		
		boolean result=false;
		
		user.accountNumber = "1004";
		user.password = "pooji123";
		user.userName = "pooji";
		user.accountBalance = 1234.00;
		

		if (userdao.insert(user)>0)
			result = true;
		
		// Assertion -> Either Test Cases Passes or It will Fail :)
		Assert.assertEquals(true, result);
		
	}
	
}
	
	